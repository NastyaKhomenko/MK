﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.IO.Ports;
using System.Drawing;
using System.Threading;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        
        byte K = 0x01;
        byte H = 0x02;
        byte O = 0x03;
        byte M = 0x04;
        byte E = 0x05;
        byte N = 0x06;
        byte A = 0x07;
        byte S = 0x08;
        byte T = 0x09;
        byte I = 0x0A;
        byte R = 0x0B;
        byte V = 0x0C;
        
        byte space = 0xFF;

       byte z0 = 0x0F;
        byte z1 = 0x11;
        byte z2 = 0x12;
        byte dot = 0xF0;

        char[] arr1 = new char[28];
        char[] arr2 = new char[10];
        int pointerInArray1 = 0;
        int pointerInArray2 = 0;
        int pointerInInnerArray1 = 0;
        int pointerInInnerArray2 = 0;
        bool isNameWasPrint = false;
        bool isBirthdayWasPrint = false;

        bool firstDataState = true;
        bool secondDataState = true;

        int numberOfMessage = 0;
        int pointerInTempArr4 = 0;
      //  int pointerInTempArr5 = 0;
        //int pointerInTempArr6 = 0;
        byte[] tempArr4 = new byte[4];
       // byte[] tempArr5 = new byte[4];
       // byte[] tempArr6 = new byte[6];
        bool repeat = false;


        static readonly byte[] crc8Table1 = new byte[]
          {
           0x00, 0x31, 0x62, 0x53, 0xC4, 0xF5, 0xA6, 0x97,
    0xB9, 0x88, 0xDB, 0xEA, 0x7D, 0x4C, 0x1F, 0x2E,
    0x43, 0x72, 0x21, 0x10, 0x87, 0xB6, 0xE5, 0xD4,
    0xFA, 0xCB, 0x98, 0xA9, 0x3E, 0x0F, 0x5C, 0x6D,
    0x86, 0xB7, 0xE4, 0xD5, 0x42, 0x73, 0x20, 0x11,
    0x3F, 0x0E, 0x5D, 0x6C, 0xFB, 0xCA, 0x99, 0xA8,
    0xC5, 0xF4, 0xA7, 0x96, 0x01, 0x30, 0x63, 0x52,
    0x7C, 0x4D, 0x1E, 0x2F, 0xB8, 0x89, 0xDA, 0xEB,
    0x3D, 0x0C, 0x5F, 0x6E, 0xF9, 0xC8, 0x9B, 0xAA,
    0x84, 0xB5, 0xE6, 0xD7, 0x40, 0x71, 0x22, 0x13,
    0x7E, 0x4F, 0x1C, 0x2D, 0xBA, 0x8B, 0xD8, 0xE9,
    0xC7, 0xF6, 0xA5, 0x94, 0x03, 0x32, 0x61, 0x50,
    0xBB, 0x8A, 0xD9, 0xE8, 0x7F, 0x4E, 0x1D, 0x2C,
    0x02, 0x33, 0x60, 0x51, 0xC6, 0xF7, 0xA4, 0x95,
    0xF8, 0xC9, 0x9A, 0xAB, 0x3C, 0x0D, 0x5E, 0x6F,
    0x41, 0x70, 0x23, 0x12, 0x85, 0xB4, 0xE7, 0xD6,
    0x7A, 0x4B, 0x18, 0x29, 0xBE, 0x8F, 0xDC, 0xED,
    0xC3, 0xF2, 0xA1, 0x90, 0x07, 0x36, 0x65, 0x54,
    0x39, 0x08, 0x5B, 0x6A, 0xFD, 0xCC, 0x9F, 0xAE,
    0x80, 0xB1, 0xE2, 0xD3, 0x44, 0x75, 0x26, 0x17,
    0xFC, 0xCD, 0x9E, 0xAF, 0x38, 0x09, 0x5A, 0x6B,
    0x45, 0x74, 0x27, 0x16, 0x81, 0xB0, 0xE3, 0xD2,
    0xBF, 0x8E, 0xDD, 0xEC, 0x7B, 0x4A, 0x19, 0x28,
    0x06, 0x37, 0x64, 0x55, 0xC2, 0xF3, 0xA0, 0x91,
    0x47, 0x76, 0x25, 0x14, 0x83, 0xB2, 0xE1, 0xD0,
    0xFE, 0xCF, 0x9C, 0xAD, 0x3A, 0x0B, 0x58, 0x69,
    0x04, 0x35, 0x66, 0x57, 0xC0, 0xF1, 0xA2, 0x93,
    0xBD, 0x8C, 0xDF, 0xEE, 0x79, 0x48, 0x1B, 0x2A,
    0xC1, 0xF0, 0xA3, 0x92, 0x05, 0x34, 0x67, 0x56,
    0x78, 0x49, 0x1A, 0x2B, 0xBC, 0x8D, 0xDE, 0xEF,
    0x82, 0xB3, 0xE0, 0xD1, 0x46, 0x77, 0x24, 0x15,
    0x3B, 0x0A, 0x59, 0x68, 0xFF, 0xCE, 0x9D, 0xAC
          };


       


        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            int num;
            comboBox1.Items.Clear();
            string[] ports = SerialPort.GetPortNames().OrderBy(a => a.Length > 3 && int.TryParse(a.Substring(3), out num) ? num : 0).ToArray();
            comboBox1.Items.AddRange(ports);
        }

        private void buttonOpenPort_Click(object sender, EventArgs e)
        {
            if (!serialPort1.IsOpen)
                try
                {
                    serialPort1.PortName = comboBox1.Text;
                    serialPort1.Open();
                    buttonOpenPort.Text = "Close";
                    comboBox1.Enabled = false;
                    button1.Visible = true;
                    button2.Visible = true;
                }
                catch
                {
                    MessageBox.Show("Port " + comboBox1.Text + " is invalid!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            else
            {
                serialPort1.Close();
                buttonOpenPort.Text = "Open";
                comboBox1.Enabled = true;
                button1.Visible = false;
                button2.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Console.WriteLine("--- Number of Message = " + ++numberOfMessage + " ---");
            pointerInArray1 = 0;
            pointerInArray2 = 0;
            repeat = false;
            pointerInInnerArray1 = 0;
            pointerInInnerArray2 = 0;
            firstDataState = true;
            secondDataState = true;
            isNameWasPrint = false;
            isBirthdayWasPrint = false;
            byte[] b1 = new byte[1];
            b1[0] = 0xC1;
            serialPort1.Write(b1, 0, 1);
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }


        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            
            byte dataFromArduino = (byte)serialPort1.ReadByte();


           Console.WriteLine(transform(dataFromArduino));

            if (pointerInArray1 < 36)
            {
                if (pointerInArray1 == 4)
                {
                    checkData(dataFromArduino, tempArr4, 4, true);
                    pointerInTempArr4 = 0;
                }
                else if (pointerInArray1 == 9)
                {
                    checkData(dataFromArduino, tempArr4, 4, true);
                    pointerInTempArr4 = 0;
                }
                else if (pointerInArray1 == 14)
                {
                    checkData(dataFromArduino, tempArr4, 4, true);
                    pointerInTempArr4 = 0;
                }
                else if (pointerInArray1 == 19)
                {
                    checkData(dataFromArduino, tempArr4, 4, true);
                    pointerInTempArr4 = 0;
                }
                else if (pointerInArray1 == 24)
                {
                    checkData(dataFromArduino, tempArr4, 4, true);
                    pointerInTempArr4 = 0;
                }
                else if (pointerInArray1 == 29)
                {
                    checkData(dataFromArduino, tempArr4, 4, true);
                    pointerInTempArr4 = 0;
                }
                else if (pointerInArray1 == 34)
                {
                    checkData(dataFromArduino, tempArr4, 4, true);
                    pointerInTempArr4 = 0;
                }
                else
                {
                    if (pointerInArray1 < 4)
                    {
                        tempArr4[pointerInTempArr4++] = dataFromArduino;
                    }
                    else if (pointerInArray1 > 4 && pointerInArray1 < 9)
                    {
                        tempArr4[pointerInTempArr4++] = dataFromArduino;
                    }
                    else if (pointerInArray1 > 9 && pointerInArray1 < 14)
                    {
                        tempArr4[pointerInTempArr4++] = dataFromArduino;
                    }
                    else if (pointerInArray1 > 14 && pointerInArray1 < 19)
                    {
                        tempArr4[pointerInTempArr4++] = dataFromArduino;
                    }
                    else if (pointerInArray1 > 19 && pointerInArray1 < 24)
                    {
                        tempArr4[pointerInTempArr4++] = dataFromArduino;
                    }
                    else if (pointerInArray1 > 24 && pointerInArray1 < 29)
                    {
                        tempArr4[pointerInTempArr4++] = dataFromArduino;
                    }
                    else if (pointerInArray1 > 29 && pointerInArray1 < 34)
                    {
                        tempArr4[pointerInTempArr4++] = dataFromArduino;
                    }
                }

                if (pointerInArray1 != 4 && pointerInArray1 != 9 && pointerInArray1 != 14
                    && pointerInArray1 != 19 && pointerInArray1 != 24 && pointerInArray1 != 29 && pointerInArray1 != 34 && pointerInInnerArray1 < 28)
                {
                    arr1[pointerInInnerArray1++] = transform(dataFromArduino);
                }
                if (dataFromArduino == 0xA5)
                {
                    byte[] b1 = new byte[1];
                    b1[0] = 0xD1;
                    serialPort1.Write(b1, 0, 1);
                }
                pointerInArray1++;
            }

            else if (pointerInArray1 == 36 && isNameWasPrint == false)
            {
                pointerInArray1++;
                isNameWasPrint = true;
                Console.WriteLine("--- Data from Slave1 --- ");
                Console.WriteLine(new String(arr1));
                if (firstDataState)
                {
                    Console.WriteLine("--- message is not broken");
                }
                else
                {
                    Console.WriteLine("--- message is broken");
                }
                Console.WriteLine("------------------------------------");
            }

            if (pointerInArray1 == 37)
            {
                if (pointerInArray2 == 4)
                {
                    checkData(dataFromArduino, tempArr4, 4, true);
                    pointerInTempArr4 = 0;
                }
                else if (pointerInArray2 == 9)
                {
                    checkData(dataFromArduino, tempArr4, 4, true);
                    pointerInTempArr4 = 0;
                }
                else if (pointerInArray2 == 14)
                {
                    checkData(dataFromArduino, tempArr4, 4, true);
                    pointerInTempArr4 = 0;
                }
                else
                {
                    if (pointerInArray2 < 4)
                    {
                        tempArr4[pointerInTempArr4++] = dataFromArduino;
                    }
                    else if (pointerInArray2 > 5 && pointerInArray2 < 9)
                    {
                        tempArr4[pointerInTempArr4++] = dataFromArduino;
                    }
                    else if (pointerInArray2 > 9 && pointerInArray2 < 14)
                    {
                        tempArr4[pointerInTempArr4++] = dataFromArduino;
                    }
                }

                if (pointerInArray2 != 4 && pointerInArray2 != 9 && pointerInArray2 != 14 && pointerInInnerArray2 < 10)
                {
                    arr2[pointerInInnerArray2++] = transform(dataFromArduino);
                }

                pointerInArray2++;

                if (pointerInArray2 == 15 && isBirthdayWasPrint == false)
                {
                    isBirthdayWasPrint = true;
                    Console.WriteLine("--- Data from Slave2 --- ");
                    Console.WriteLine(new String(arr2));
                    if (secondDataState)
                    {
                        Console.WriteLine("--- message is not broken");
                    }
                    else
                    {
                        Console.WriteLine("--- message is broken");
                    }
                    Console.WriteLine("------------------------------------");
                    Console.WriteLine();
                    Console.WriteLine();
                    sendNewMessage();
                }
            }

        }

        private void sendNewMessage()
        {
            if (numberOfMessage < 5)
            {
                Console.WriteLine("--- Number of Message = " + ++numberOfMessage + " ---");
                pointerInArray1 = 0;
                pointerInArray2 = 0;
                repeat = false;
                pointerInInnerArray1 = 0;
                pointerInInnerArray2 = 0;
                firstDataState = true;
                secondDataState = true;
                isNameWasPrint = false;
                isBirthdayWasPrint = false;
                byte[] b1 = new byte[1];
                b1[0] = 0xC1;
                serialPort1.Write(b1, 0, 1);
            }
        }

        private void checkData(byte oldCRC, byte[] arr, int len, bool isFirstMessage)
        {


            byte newCRC = calculateCRC(arr, len);
            

            if (newCRC != oldCRC)
            {
                if (isFirstMessage)
                {
                    firstDataState = false;
                }
                else
                {
                    secondDataState = false;
                }

            }
        }

       /* private byte calculateCRC(byte[] bytes, int len, byte poly, byte crcStart,
                   byte finalXOR)
        {
            /*byte crc = crcStart;
            int i;
            int pointer = 0;

            while (len > 0)
            {
                len--;
                byte b = bytes[pointer++];
                b = reflect8(b);
                crc ^= b;

                for (i = 0; i < 8; i++)
                {
                    if ((crc & 0x80) != 0)
                    {
                        crc = (byte)((crc << 1) ^ poly);
                    }
                    else
                    {
                        crc <<= 1;
                    }

                }
            }
            crc = reflect8(crc);
            crc ^= finalXOR;
            return crc;*/

         
            // CRC-8 for Dallas iButton products from Maxim/Dallas AP Note 27
          

            public static byte calculateCRC(byte[] bytes, int len)
            {
                byte crc = 0xFD;
                for (var i = 0; i < len; i++)
                    crc = crc8Table1[crc ^ bytes[i]];
                return crc;
            
        }
       

        // }

        /* private byte reflect8(byte x)
         {
             byte result = 0;
             int c;
             for (c = 0; c < 8; c++)
             {
                 result <<= 1;
                 if ((x & 1) == 1)
                     result++;
                 x >>= 1;
             }
             return result;
         }*/

        private char transform(byte b)
        {
            if (b == K) return 'K';
            if (b == H) return 'H';
            if (b == O) return 'O';
            if (b == M) return 'M';
            if (b == E) return 'E';
            if (b == N) return 'N';
            if (b == A) return 'A';
            if (b == S) return 'S';
            if (b == T) return 'T';
            if (b == I) return 'I';
            if (b == R) return 'R';
            if (b == V) return 'V';

            

            if (b == z0) return '0';
            if (b == z1) return '1';
            if (b == z2) return '2';
           

            if (b == dot) return '.';
            if (b == space) return ' ';
            return '#';

        }

        private void panelM_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
